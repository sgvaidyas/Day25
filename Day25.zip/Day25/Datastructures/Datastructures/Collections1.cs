﻿using System;
using System.Collections.Generic;

namespace Datastructures
{
    class Collections1
    {
        static void Main(string[] args)
        {
            Stack<int> marks = new Stack<int>();

            marks.Push(22);
            marks.Push(44);
            marks.Push(55);

            foreach(int x in marks)
                Console.WriteLine(x);

            Console.WriteLine("\n\nPOPPED ELEMENT = " + marks.Pop());
            Console.WriteLine("\n top most element = "+ marks.Peek());
            Console.WriteLine("\n\n");
            foreach (int x in marks)
                Console.WriteLine(x);

            Console.WriteLine("__________\n\n QUEUE OPERATIONS");
            Queue<string> empnames = new Queue<string>();
            empnames.Enqueue("Chandan");
            empnames.Enqueue("MAdhuri");
            empnames.Enqueue("Srivani");

            foreach (string e in empnames)
                Console.WriteLine(e);

            Console.WriteLine("PEEK = " + empnames.Peek());
            Console.WriteLine("DEQUEUE = " + empnames.Dequeue());
            Console.WriteLine("PEEK = " + empnames.Peek());
        }
    }
}
