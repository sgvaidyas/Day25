﻿using System;

namespace Datastructures
{
    class Node
    {
        public int data;
        public Node next;
        public Node(int x)
        {
            data = x;
            next = null;
        }
    }
    class SinglyLinked
    {
        public Node head;
        public int cnt;

        SinglyLinked()
        {
            head = null;
            cnt = 0;
        }
        public void insertbegin(int ele)
        {
            Node newnode = new Node(ele);

            if (head == null)
                head = newnode;
            else
            {
                newnode.next = head;
                head = newnode;
            }
            cnt++;
        }
        public void insertend(int ele)
        {
            Node newnode = new Node(ele);

            if (head == null)
                head = newnode;
            else
            {
                Node trav = head;
                while (trav.next != null)
                {
                    trav = trav.next;
                }
                trav.next = newnode;
            }
            cnt++;
        }
        public void insertpos(int pos, int ele)
        {
            if (pos == 1)
                insertbegin(ele);
            else if (pos == cnt+1)
                insertend(ele);
            else
            {
                Node newnode = new Node(ele);
                Node pp, cp;
                pp = cp = head;
                for(int i=1;i<pos;i++)
                {
                    pp = cp;
                    cp = cp.next;
                }
                pp.next = newnode;
                newnode.next = cp;
                cnt++;
            }

        }

        public void deletebegin()
        {
            if(head==null)
                Console.WriteLine("List empty");
            else
            {
                Node ptr = head;
                Console.WriteLine("Delting element = " + head.data);
                head = head.next;
                ptr = null;
                cnt--;
            }
        }

        public void deleteend()
        {
            if (head == null)
                Console.WriteLine("List empty");
            else
            {
                Node pp, cp;
                pp=cp= head;

                while(cp.next!=null)
                {
                    pp = cp;
                    cp = cp.next;
                }
                if(cp==pp)
                {
                    Console.WriteLine("Delting element = " + cp.data);
                    head = null;
                }
                else
                {
                    pp.next = null;
                    Console.WriteLine("Delting element = " + cp.data);
                    cp = null;
                }
                cnt--;
            }
        }




        public void display()
        {
            if(head == null)
                Console.WriteLine("LIST EMPTY");
            else
            {
                Node trav =  head ;
                Console.WriteLine("the list elements are =");
                while(trav!=null)
                {
                    Console.Write(trav.data + "\t");
                    trav = trav.next;
                }
                Console.WriteLine();
            }
        }
        static void Main(string[] args)
        {
            SinglyLinked ob = new SinglyLinked();
            bool flag = true;
            int ele,pos;

            while(flag)
            {
                Console.WriteLine("1 Insert in the beginning ");
                Console.WriteLine("2 Insert in the end ");
                Console.WriteLine("3 Insert at a position ");
                Console.WriteLine("4 Delete begin ");
                Console.WriteLine("7 Display");
                Console.WriteLine("8 Exit");
                Console.WriteLine("Enter choice");
                int ch = int.Parse(Console.ReadLine());
                switch(ch)
                {
                    case 1:Console.WriteLine("Enter the element");
                           ele = int.Parse(Console.ReadLine());
                           ob.insertbegin(ele);
                           break;
                    case 2:
                        Console.WriteLine("Enter the element");
                        ele = int.Parse(Console.ReadLine());
                        ob.insertend(ele);
                        break;
                    case 3: Console.WriteLine("Enter the position");
                        do
                        {
                            Console.WriteLine("Positionbetween {0} to {1}", 1, ob.cnt + 1);
                            pos = int.Parse(Console.ReadLine());
                        } while (pos < 1 || pos > ob.cnt + 1);
                        Console.WriteLine("Enter the element");
                        ele = int.Parse(Console.ReadLine());
                        ob.insertpos(pos, ele);

                        break;
                    case 4:ob.deletebegin();break;
                    case 5:ob.deleteend();break;
                    case 7: ob.display();break;
                    case 8:flag = false;break;
                    default: Console.WriteLine("invalid choice");
                        break;
                }
            }           
        }
    }
}
