﻿using System;

namespace Datastructures
{
    class Queue
    {
        public int front, rear,max;
        public int[] a;
        Queue()
        {
            front = 0;
            rear = -1;
            max = 5;
            a = new int[5];
        }
        public void enqueue()
        {
            if (rear == max - 1)
                Console.WriteLine("Overflow");
            else
            {
                int ele;
                Console.WriteLine("Enterthe ele = ");
                ele = int.Parse(Console.ReadLine());
                a[++rear] = ele;
            }
        }

        public void dequeue()
        {
            if (front > rear)
            {
                Console.WriteLine("Underflow");
                front = 0;
                rear = -1;
            }
            else
                Console.WriteLine("Deleted = " + a[front++]);
        }
        public void display()
        {
            if (front > rear)
                  Console.WriteLine("Empty");
            else
            {
                Console.WriteLine("Queue elements = ");
                for(int i=front;i<=rear;i++)
                    Console.Write(a[i] + "\t");
                Console.WriteLine();
            }

        }
        static void Main(string[] args)
        {
            Queue ob = new Queue();
            int ch;
            do
            {
                Console.WriteLine("The choices 1 ENQUEUE 2 DEQUEUE 3 DISPLAY 4 EXIT");
                ch = int.Parse(Console.ReadLine());
                switch (ch)
                {
                    case 1: ob.enqueue(); break;
                    case 2: ob.dequeue(); break;
                    case 3: ob.display(); break;
                    case 4: break;
                    default: Console.WriteLine("Invalid choice "); break;
                }
            } while (ch != 4);
        }
    }
}
