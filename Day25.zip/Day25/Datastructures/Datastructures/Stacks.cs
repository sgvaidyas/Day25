﻿using System;

namespace Datastructures
{
    class Stacks
    {
        public int[] a;
        public int max, top;
        Stacks()
        {
            top = -1;
            max = 5;
            a = new int[max];
        }
        public void push()
        {
            if(top==max-1)
                Console.WriteLine("Overflow");
            else
            {
                int ele;
                Console.WriteLine("Enterthe ele = ");
                ele = int.Parse(Console.ReadLine());
                a[++top] = ele;
            }
        }
        public void pop()
        {
            if(top==-1)
                Console.WriteLine("Underflow");
            else
                Console.WriteLine("DELETED = "+a[top--]);
        }
        public void display()
        {
            if (top == -1)
                Console.WriteLine("Empty");
            else
            {
                Console.WriteLine("STACK ELE=");
                for(int i=top;i>=0;i--)
                    Console.WriteLine(a[i]);
            }         

        }
        static void Main(string[] args)
        {
            Stacks ob = new Stacks();
            int ch;
            do
            {
                Console.WriteLine("The choices 1 PUSH 2 POP 3 DISPLAY 4 EXIT");
                ch = int.Parse(Console.ReadLine());
                switch (ch)
                {
                    case 1: ob.push(); break;
                    case 2: ob.pop(); break;
                    case 3: ob.display(); break;
                    case 4: break;
                    default: Console.WriteLine("Invalid choice "); break;
                }
            } while (ch!=4);
        }
    }
}
